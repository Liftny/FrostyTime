/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

/**
 *
 * @author Ernesto Robles
 */
public class Cliente {
    private String ced;
    private String nombre;
    private String telefono;
    private String email;
    private String membresia;

    public Cliente(String ced, String nombre, String telefono, String email, String membresia) {
        this.ced = ced;
        this.nombre = nombre;
        this.telefono = telefono;
        this.email = email;
        this.membresia = membresia;
    }

    public Cliente() {
    }
    
    
    public String getCed() {
        return ced;
    }

    public void setCed(String ced) {
        this.ced = ced;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getMembresia() {
        return membresia;
    }

    public void setMembresia(String membresia) {
        this.membresia = membresia;
    }
}
