/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Config;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ernesto Robles
 */
public abstract class ErrorHandler {
    private static final Logger logger = Logger.getLogger(ErrorHandler.class.getName());
    private String lastErrorMessage = ""; // Variable para guardar el �ltimo mensaje de error

    protected void logAndSaveError(String message, Exception e) {
        // Asegurar que message no sea nulo
        if (message == null) {
            message = "Error desconocido"; // Mensaje por defecto si no se proporciona uno
        }

        // Asignar el mensaje de error a la variable de instancia
        lastErrorMessage = message;

        // Si hay una excepci�n, registramos tambi�n los detalles de la excepci�n
        if (e != null) {
            lastErrorMessage += "\nDetalles: " + e.getMessage();
            logger.log(Level.SEVERE, lastErrorMessage, e);
        } else {
            logger.log(Level.SEVERE, lastErrorMessage); // Si no hay excepci�n, solo el mensaje
        }
    }

    public String getLastErrorMessage() {
        return lastErrorMessage; // Obtener el �ltimo mensaje de error guardado
    }
}

