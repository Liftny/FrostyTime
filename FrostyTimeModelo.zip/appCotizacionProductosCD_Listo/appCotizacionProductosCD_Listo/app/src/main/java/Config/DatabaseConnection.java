/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


/**
 *
 * @author erobles
 */
public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/frostytime";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    private static Connection connection;

    // M�todo para obtener la conexi�n
    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("Conexion exitosa a la base de datos.");
            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
                throw new SQLException("Error al conectar a la base de datos: " + e.getMessage());
            }
        }
        return connection;
    }

    // M�todo para cerrar la conexi�n
    public static void closeConnection() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

    // M�todo para validar entradas (para prevenir SQL Injection)
    public static String validateInput(String input) {
        if (input == null || input.trim().isEmpty()) {
            throw new IllegalArgumentException("La entrada no puede estar vac�a.");
        }
        return input.replaceAll("[^a-zA-Z0-9@._-]", "");
    }
}
