/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Config;

/**
 *
 * @author Ernesto Robles
 */
import javax.swing.JTextField;

public class InputValidator {

    // Valida si un campo de texto est� vac�o
    public boolean isFieldEmpty(JTextField... textFields) {
    for (JTextField textField : textFields) {
        if (textField.getText().trim().isEmpty()) {
            return true;  // Si alg�n campo est� vac�o, retorna true
        }
    }
    return false;  // Si ninguno est� vac�o, retorna false
}

    // Valida si el texto ingresado contiene solo letras
    public boolean isTextOnly(JTextField textField) {
        return textField.getText().matches("^[a-zA-Z������������\\s]+$");
    }

    // Valida si el texto ingresado contiene solo n�meros enteros
    public boolean isInteger(JTextField textField) {
        return textField.getText().matches("^\\d+$");
    }

    // Valida si el texto ingresado contiene un n�mero decimal v�lido (sin m�ltiples puntos o comas)
    public boolean isValidDecimal(JTextField textField) {
        String text = textField.getText();
        String decimalSeparator = getDecimalSeparator();
        String regex = "^\\d+(\\" + decimalSeparator + "\\d{1,2})?$";
        return text.matches(regex);
    }

    // Obtiene el separador decimal seg�n la configuraci�n regional de la m�quina
    private String getDecimalSeparator() {
        return String.valueOf(java.text.DecimalFormatSymbols.getInstance().getDecimalSeparator());
    }
}
