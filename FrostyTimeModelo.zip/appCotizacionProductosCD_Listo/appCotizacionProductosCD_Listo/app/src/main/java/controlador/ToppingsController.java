/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import Config.DatabaseConnection;
import Config.ErrorHandler;
import Config.InputValidator;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import modelos.Toppings;

/**
 *
 * @author Ernesto Robles
 */
public class ToppingsController extends ErrorHandler{
    
    private InputValidator inputValidator;
    private Toppings toppings=new Toppings();

    public ToppingsController() {
        inputValidator=new InputValidator();
    }

    public InputValidator validator() {
        return inputValidator;
    }

    public Toppings infoToppings() {
        return toppings;
    }
    
    public boolean addToppings() {
        String checkSql = "SELECT COUNT(*) FROM toppings WHERE codToppings = ? OR nombreToppings = ?";
        String insertSql = "INSERT INTO toppings (codToppings, nombreToppings, categoriaToppings, precioToppings) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection()) {
            // Verificar si el c�digo o nombre ya existe
            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setString(1, DatabaseConnection.validateInput(toppings.getCodigo()));
                checkStmt.setString(2, toppings.getNombre());

                try (ResultSet rs = checkStmt.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        logAndSaveError("El codigo o el nombre del topping ya existe en la base de datos.", null);
                        return false;
                    }
                }
            }
            // Insertar el producto si no hay duplicados
            try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                insertStmt.setString(1, DatabaseConnection.validateInput(toppings.getCodigo()));
                insertStmt.setString(2, toppings.getNombre());
                insertStmt.setString(3, toppings.getCategoria());
                insertStmt.setDouble(4, toppings.getPrecio());
                return insertStmt.executeUpdate() > 0;
            }

        } catch (SQLException e) {
            logAndSaveError("Error al insertar el topping en la base de datos: " + toppings, e);
        }finally {
            try {
                DatabaseConnection.closeConnection();
            } catch (SQLException e) {
                logAndSaveError("Error al cerrar la conexion a la base de datos.", e);
            }
        }
        return false;
    }
    
}
