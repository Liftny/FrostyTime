/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import Config.DatabaseConnection;
import Config.ErrorHandler;
import Config.InputValidator;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import modelos.Trabajador;

/**
 *
 * @author Ernesto Robles
 */
public class TrabajadorController extends ErrorHandler{
    
    private InputValidator inputValidator;
    private Trabajador trabajador=new Trabajador();

    public TrabajadorController() {
        inputValidator=new InputValidator();
    }

    public InputValidator validator() {
        return inputValidator;
    }

    public Trabajador infoTrabajador() {
        return trabajador;
    }
    
    public boolean addTrabajador() {
        String checkSql = "SELECT COUNT(*) FROM trabajador WHERE cedTrabajador = ? OR nombreTrabajador = ?";
        String insertSql = "INSERT INTO trabajador (cedTrabajador, nombreTrabajador, area_trabajo, tipo_horario) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection()) {
            // Verificar si el c�digo o nombre ya existe
            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setString(1, DatabaseConnection.validateInput(trabajador.getCedula()));
                checkStmt.setString(2, trabajador.getNombre());

                try (ResultSet rs = checkStmt.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        logAndSaveError("La cédula o el nombre del trabajador ya existe en la base de datos.", null);
                        return false;
                    }
                }
            }
            // Insertar el producto si no hay duplicados
            try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                insertStmt.setString(1, DatabaseConnection.validateInput(trabajador.getCedula()));
                insertStmt.setString(2, trabajador.getNombre());
                insertStmt.setString(3, trabajador.getAreaTrabajo());
                insertStmt.setString(4, trabajador.getTipoHorario());
                return insertStmt.executeUpdate() > 0;
            }

        } catch (SQLException e) {
            logAndSaveError("Error al insertar el trabajador en la base de datos: " + trabajador, e);
        }finally {
            try {
                DatabaseConnection.closeConnection();
            } catch (SQLException e) {
                logAndSaveError("Error al cerrar la conexion a la base de datos.", e);
            }
        }
        return false;
    }
    
}
