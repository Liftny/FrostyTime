/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import Config.DatabaseConnection;
import Config.ErrorHandler;
import Config.InputValidator;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import modelos.Cliente;

/**
 *
 * @author Ernesto Robles
 */
public class ClienteController extends ErrorHandler{
    
    private InputValidator inputValidator;
    private Cliente cliente=new Cliente();

    public ClienteController() {
        inputValidator=new InputValidator();
    }

    public InputValidator validator() {
        return inputValidator;
    }

    public Cliente infoCliente() {
        return cliente;
    }
    
    public boolean addCliente() {
        String checkSql = "SELECT COUNT(*) FROM cliente WHERE cedCliente = ? OR nombreCliente = ?";
        String insertSql = "INSERT INTO cliente (cedCliente, nombreCliente, telefonoCliente, emailCliente, membresiaCliente) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection()) {
            // Verificar si el c�digo o nombre ya existe
            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setString(1, DatabaseConnection.validateInput(cliente.getCed()));
                checkStmt.setString(2, cliente.getNombre());

                try (ResultSet rs = checkStmt.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        logAndSaveError("La cédula o el nombre del cliente ya existe en la base de datos.", null);
                        return false;
                    }
                }
            }
            // Insertar el producto si no hay duplicados
            try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                insertStmt.setString(1, DatabaseConnection.validateInput(cliente.getCed()));
                insertStmt.setString(2, cliente.getNombre());
                insertStmt.setString(3, cliente.getTelefono());
                insertStmt.setString(4, cliente.getEmail());
                insertStmt.setString(5, cliente.getMembresia());
                return insertStmt.executeUpdate() > 0;
            }

        } catch (SQLException e) {
            logAndSaveError("Error al insertar el cliente en la base de datos: " + cliente, e);
        }finally {
            try {
                DatabaseConnection.closeConnection();
            } catch (SQLException e) {
                logAndSaveError("Error al cerrar la conexion a la base de datos.", e);
            }
        }
        return false;
    }
    
}
