/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import Config.DatabaseConnection;
import Config.ErrorHandler;
import Config.InputValidator;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import modelos.Helado;

/**
 *
 * @author Ernesto Robles
 */
public class HeladoController extends ErrorHandler{
    
    private InputValidator inputValidator;
    private Helado helado=new Helado();

    public HeladoController() {
        inputValidator=new InputValidator();
    }

    public InputValidator validator() {
        return inputValidator;
    }

    public Helado infoHelado() {
        return helado;
    }
    
    public boolean addHelado() {
        String checkSql = "SELECT COUNT(*) FROM helado WHERE codHelado = ? OR nombreHelado = ?";
        String insertSql = "INSERT INTO helado (codHelado, nombreHelado, categoriaHelado, precioHelado) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection()) {
            // Verificar si el c�digo o nombre ya existe
            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setString(1, DatabaseConnection.validateInput(helado.getCodigo()));
                checkStmt.setString(2, helado.getNombre());

                try (ResultSet rs = checkStmt.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        logAndSaveError("El codigo o el nombre del helado ya existe en la base de datos.", null);
                        return false;
                    }
                }
            }
            // Insertar el producto si no hay duplicados
            try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                insertStmt.setString(1, DatabaseConnection.validateInput(helado.getCodigo()));
                insertStmt.setString(2, helado.getNombre());
                insertStmt.setString(3, helado.getCategoria());
                insertStmt.setDouble(4, helado.getPrecio());
                return insertStmt.executeUpdate() > 0;
            }

        } catch (SQLException e) {
            logAndSaveError("Error al insertar el helado en la base de datos: " + helado, e);
        }finally {
            try {
                DatabaseConnection.closeConnection();
            } catch (SQLException e) {
                logAndSaveError("Error al cerrar la conexion a la base de datos.", e);
            }
        }
        return false;
    }
    
}
