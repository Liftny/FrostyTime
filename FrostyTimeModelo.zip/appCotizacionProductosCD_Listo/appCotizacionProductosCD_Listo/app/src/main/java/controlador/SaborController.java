/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import Config.DatabaseConnection;
import Config.ErrorHandler;
import Config.InputValidator;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import modelos.Sabor;

/**
 *
 * @author Ernesto Robles
 */
public class SaborController extends ErrorHandler{
    
    private InputValidator inputValidator;
    private Sabor sabor=new Sabor();

    public SaborController() {
        inputValidator=new InputValidator();
    }

    public InputValidator validator() {
        return inputValidator;
    }

    public Sabor infoSabor() {
        return sabor;
    }
    
    public boolean addSabor() {
        String checkSql = "SELECT COUNT(*) FROM sabor WHERE codSabor = ? OR nombreSabor = ?";
        String insertSql = "INSERT INTO sabor (codSabor, nombreSabor, costoSabor, precioSabor) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection()) {
            // Verificar si el c�digo o nombre ya existe
            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setString(1, DatabaseConnection.validateInput(sabor.getCodigo()));
                checkStmt.setString(2, sabor.getNombre());

                try (ResultSet rs = checkStmt.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        logAndSaveError("El codigo o el nombre del sabor ya existe en la base de datos.", null);
                        return false;
                    }
                }
            }
            // Insertar el producto si no hay duplicados
            try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                insertStmt.setString(1, DatabaseConnection.validateInput(sabor.getCodigo()));
                insertStmt.setString(2, sabor.getNombre());
                insertStmt.setDouble(3, sabor.getCosto());
                insertStmt.setDouble(4, sabor.getPrecio());
                return insertStmt.executeUpdate() > 0;
            }

        } catch (SQLException e) {
            logAndSaveError("Error al insertar el sabor en la base de datos: " + sabor, e);
        }finally {
            try {
                DatabaseConnection.closeConnection();
            } catch (SQLException e) {
                logAndSaveError("Error al cerrar la conexion a la base de datos.", e);
            }
        }
        return false;
    }
    
}
